import Foundation
import Alamofire

struct MyData: Codable {
    let id: Int
    let name: String
}

func fetchData(from url: String) {
    AF.request(url).responseDecodable(of: MyData.self) { response in
        switch response.result {
        case .success(let value):
            print("Response JSON: \(value)")
        case .failure(let error):
            print("Error: \(error)")
        }
    }
}

let url = "https://api.example.com/data"
fetchData(from: url)
